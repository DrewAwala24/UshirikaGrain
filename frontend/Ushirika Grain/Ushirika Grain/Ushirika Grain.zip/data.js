/* ==========================================================================
   Ushirika Grain: sample data and business logic (shared by every page)

   Replace this file with calls to the Spring Boot REST API when the backend
   is ready:
     GET  /api/depots
     GET  /api/deposits
     POST /api/deposits
     GET  /api/deposits/{trackingId}
   The PostgreSQL schema for this data is in database/ushirika_grain.sql.
   Deposits recorded on the Intake page are kept in this browser only
   (localStorage) so you can click through the whole flow without a server.
   ========================================================================== */
(function (w) {
  'use strict';

  var KG = 90;          // kilograms in one bag
  var LIMIT = 13.5;     // safe storage moisture limit, percent
  var DAY = 864e5;
  var NOW = Math.floor(Date.now() / 36e5) * 36e5;

  /* ---------- small helpers ---------- */
  var pad = function (n) { return String(n).padStart(2, '0'); };
  var nf = function (n) { return Math.round(n).toLocaleString('en-US'); };
  var esc = function (s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  var fmtDay = function (ts) { return new Date(ts).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }); };
  var fmtDate = function (ts) { var d = new Date(ts); return fmtDay(ts) + ', ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); };
  var sum = function (a, f) { return a.reduce(function (t, x) { return t + f(x); }, 0); };

  function makeStore(kind) {
    var real = null, mem = {};
    try { real = w[kind]; real.setItem('__z', '1'); real.removeItem('__z'); } catch (e) { real = null; }
    return {
      get: function (k) { try { return real ? real.getItem(k) : (k in mem ? mem[k] : null); } catch (e) { return null; } },
      set: function (k, v) { try { if (real) real.setItem(k, v); else mem[k] = v; } catch (e) { /* ignore */ } },
      remove: function (k) { try { if (real) real.removeItem(k); else delete mem[k]; } catch (e) { /* ignore */ } }
    };
  }
  var local = makeStore('localStorage'), sess = makeStore('sessionStorage');

  /* ---------- depots ---------- */
  var DEPOTS = [
    { id: 'KTL', name: 'Kitale Central', cap: 12000, stored: 9650, rate: 380 },
    { id: 'END', name: 'Endebess', cap: 6000, stored: 5420, rate: 310 },
    { id: 'KWZ', name: 'Kwanza', cap: 5000, stored: 2100, rate: 120 },
    { id: 'SBT', name: 'Saboti', cap: 4500, stored: 4180, rate: 260 },
    { id: 'CHG', name: 'Cherangany', cap: 6500, stored: 3300, rate: 190 },
    { id: 'KMN', name: 'Kiminini', cap: 5500, stored: 1900, rate: 95 }
  ];
  function rng(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  DEPOTS.forEach(function (d, i) {
    var r = rng(i * 977 + 13);
    d.intake = Array.from({ length: 14 }, function () { return Math.round(d.rate * (0.7 + 0.6 * r())); });
  });
  var depotById = function (id) { return DEPOTS.filter(function (d) { return d.id === id; })[0]; };
  var depotName = function (id) { return depotById(id).name + ' depot'; };
  function history(d) {
    var out = new Array(14), v = d.stored;
    for (var i = 13; i >= 0; i--) { out[i] = Math.max(0, v); v -= d.intake[i]; }
    return out;
  }
  function metrics(d) {
    var rate = Math.max(1, d.intake.slice(-7).reduce(function (a, b) { return a + b; }, 0) / 7);
    var free = d.cap - d.stored, util = d.stored / d.cap, days = free / rate, st = 'ok';
    if (util >= 0.9 || days <= 3) st = 'crit'; else if (util >= 0.8 || days <= 10) st = 'warn';
    return { rate: rate, free: free, util: util, days: days, st: st };
  }
  var ST = { ok: { t: 'Open', cls: 's-ok' }, warn: { t: 'Filling', cls: 's-warn' }, crit: { t: 'Redirect', cls: 's-crit' } };
  function daysTxt(d) {
    if (d < 1) return 'under a day';
    if (d < 2) return 'about 1 day';
    if (d > 60) return 'over 60 days';
    return 'about ' + Math.round(d) + ' days';
  }

  /* ---------- AI: spoilage risk (rule-based) ----------
     Wet grain (above the safe limit) spoils faster the longer it sits,
     so days in store count more when moisture is high. */
  function score(m, days) {
    var base = Math.max(0, m - 12.5) * 14, time = days * (m > LIMIT ? 2.2 : 0.4);
    return Math.min(100, Math.round(base + time));
  }
  var level = function (s) { return s >= 65 ? 'high' : s >= 35 ? 'med' : 'low'; };
  var LV = {
    high: { t: 'High', cls: 's-crit', act: 'Dry to 13.5% or dispatch first' },
    med: { t: 'Medium', cls: 's-warn', act: 'Re-test moisture in 3 days and aerate' },
    low: { t: 'Low', cls: 's-ok', act: 'Store as normal' }
  };
  function riskOf(d) {
    var days = Math.max(0, (Date.now() - d.ts) / DAY), s = score(d.m, days);
    return { s: s, lv: level(s), days: days };
  }

  /* ---------- ledger with a hash chain (tamper-evident) ---------- */
  function cyrb53(str) {
    var h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (var i = 0, ch; i < str.length; i++) {
      ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
  }
  var hashOf = function (d) {
    return cyrb53([d.prev, d.id, d.farmer, d.depot, d.bags, d.m, d.ts].join('|')).toString(16).padStart(14, '0');
  };
  var DEPOSITS = [], seq = 40;

  function addDeposit(o) {
    var prev = DEPOSITS.length ? DEPOSITS[DEPOSITS.length - 1].hash : 'GENESIS';
    var ts = o.ts || Date.now(), dt = new Date(ts), id = o.id;
    if (id) {
      var n = parseInt(id.split('-').pop(), 10);
      if (n > seq) seq = n;
    } else {
      id = 'UG-' + o.depot + '-' + String(dt.getFullYear()).slice(2) + pad(dt.getMonth() + 1) + pad(dt.getDate()) + '-' + String(++seq).padStart(4, '0');
    }
    var d = { id: id, farmer: o.farmer, phone: o.phone, sub: o.sub, depot: o.depot, crop: o.crop, bags: o.bags, m: o.m, ts: ts, pay: o.pay || 'Pending', prev: prev };
    d.hash = hashOf(d);
    DEPOSITS.push(d);
    return d;
  }

  [
    ['Kiplagat Chebet', '481', 'Kitale', 'KTL', 'Maize', 38, 13.2, 12, 'Paid'],
    ['Naliaka Wafula', '207', 'Kiminini', 'KMN', 'Maize', 52, 13.4, 11, 'Paid'],
    ['Simiyu Barasa', '935', 'Endebess', 'END', 'Maize', 64, 14.9, 9, 'Approved'],
    ['Kipchirchir Koech', '342', 'Kwanza', 'KWZ', 'Maize', 30, 13.0, 8, 'Paid'],
    ['Nekesa Wekesa', '618', 'Saboti', 'SBT', 'Maize', 47, 16.2, 7, 'Pending'],
    ['Mwangi Njoroge', '770', 'Kitale', 'KTL', 'Maize', 70, 15.6, 6, 'Approved'],
    ['Chepkemoi Lagat', '054', 'Endebess', 'END', 'Maize', 44, 17.1, 5, 'Pending'],
    ['Barasa Wanyama', '269', 'Saboti', 'SBT', 'Maize', 58, 14.4, 4, 'Pending'],
    ['Alice Nasimiyu', '803', 'Kiminini', 'KMN', 'Maize', 33, 13.3, 4, 'Approved'],
    ['Kibet Rotich', '126', 'Cherangany', 'CHG', 'Maize', 40, 14.8, 3, 'Pending'],
    ['Joyce Naserian', '590', 'Kwanza', 'KWZ', 'Wheat', 26, 13.6, 3, 'Pending'],
    ['Peter Wafula', '417', 'Kitale', 'KTL', 'Maize', 80, 13.9, 2, 'Pending'],
    ['Grace Chepkoech', '732', 'Saboti', 'SBT', 'Maize', 36, 15.9, 2, 'Pending'],
    ['Omondi Ouma', '185', 'Endebess', 'END', 'Maize', 29, 13.1, 1, 'Pending'],
    ['Esther Wambui', '964', 'Kitale', 'KTL', 'Beans', 18, 12.9, 0, 'Pending'],
    ['Samuel Kiprono', '371', 'Kiminini', 'KMN', 'Maize', 60, 14.2, 0, 'Pending']
  ].forEach(function (r, i) {
    addDeposit({ farmer: r[0], phone: r[1], sub: r[2], depot: r[3], crop: r[4], bags: r[5], m: r[6], ts: NOW - r[7] * DAY - ((i * 53) % 420) * 60000, pay: r[8] });
  });

  /* ---------- deposits recorded in this browser ---------- */
  var EXTRAS_KEY = 'ushirika.extras.v1';
  function loadExtras() {
    try { return JSON.parse(local.get(EXTRAS_KEY) || '[]'); } catch (e) { return []; }
  }
  function applyToDepot(d, bags) { d.stored += bags; d.intake[13] += bags; }
  loadExtras().forEach(function (x) {
    var dep = depotById(x.depot);
    if (!dep) return;
    addDeposit(x);
    applyToDepot(dep, x.bags);
  });
  function recordIntake(o) {
    var dep = depotById(o.depot);
    var d = addDeposit(o);
    applyToDepot(dep, o.bags);
    var all = loadExtras();
    all.push({ id: d.id, farmer: d.farmer, phone: d.phone, sub: d.sub, depot: d.depot, crop: d.crop, bags: d.bags, m: d.m, ts: d.ts, pay: d.pay });
    local.set(EXTRAS_KEY, JSON.stringify(all));
    return d;
  }
  function resetExtras() { local.remove(EXTRAS_KEY); }

  var chainOk = function (d) { return hashOf(d) === d.hash; };
  function verifyLedger() {
    for (var i = 0; i < DEPOSITS.length; i++) {
      var d = DEPOSITS[i], prev = i ? DEPOSITS[i - 1].hash : 'GENESIS';
      if (d.prev !== prev || !chainOk(d)) return { ok: false, at: d };
    }
    return { ok: true, n: DEPOSITS.length };
  }
  function find(id) {
    id = String(id || '').trim().toUpperCase();
    return DEPOSITS.filter(function (d) { return d.id === id; })[0] || null;
  }

  /* ---------- session (front-end only until the backend login exists) ---------- */
  var SKEY = 'ushirika.session.v1';
  function nameFromEmail(e) {
    var base = e.split('@')[0].replace(/[._-]+/g, ' ').replace(/\d+/g, '').trim() || 'Officer';
    return base.replace(/\b\w/g, function (c) { return c.toUpperCase(); });
  }
  var session = {
    get: function () {
      var raw = local.get(SKEY) || sess.get(SKEY);
      if (!raw) return null;
      try { return JSON.parse(raw); } catch (e) { return null; }
    },
    set: function (user, remember) {
      var s = JSON.stringify(user);
      local.remove(SKEY); sess.remove(SKEY);
      (remember ? local : sess).set(SKEY, s);
    },
    clear: function () { local.remove(SKEY); sess.remove(SKEY); },
    setNext: function (p) { sess.set('ushirika.next', p); },
    takeNext: function () { var p = sess.get('ushirika.next'); sess.remove('ushirika.next'); return p; },
    nameFromEmail: nameFromEmail
  };
  var setLookup = function (id) { sess.set('ushirika.lookup', id); };
  var takeLookup = function () { var id = sess.get('ushirika.lookup'); sess.remove('ushirika.lookup'); return id; };

  w.Ushirika = {
    KG: KG, LIMIT: LIMIT, DAY: DAY, NOW: NOW,
    DEPOTS: DEPOTS, DEPOSITS: DEPOSITS,
    depotById: depotById, depotName: depotName, history: history, metrics: metrics, ST: ST, daysTxt: daysTxt,
    score: score, level: level, LV: LV, riskOf: riskOf,
    hashOf: hashOf, chainOk: chainOk, verifyLedger: verifyLedger,
    recordIntake: recordIntake, resetExtras: resetExtras, find: find,
    session: session, setLookup: setLookup, takeLookup: takeLookup,
    nf: nf, esc: esc, pad: pad, fmtDay: fmtDay, fmtDate: fmtDate, sum: sum,
    PAY: { Paid: 's-ok', Approved: 's-info', Pending: 's-warn' }
  };
})(window);
