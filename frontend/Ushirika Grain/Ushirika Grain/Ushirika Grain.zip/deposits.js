/* Deposits: receipt lookup, searchable ledger, tamper-evidence demo. */
(function () {
  'use strict';
  if (window.UshirikaBlocked) return;
  var Z = window.Ushirika, U = window.UshirikaUI, D = Z.DEPOTS, esc = Z.esc, nf = Z.nf;
  var $ = function (s) { return document.querySelector(s); };
  var topRisk = Z.DEPOSITS.slice().sort(function (a, b) { return Z.riskOf(b).s - Z.riskOf(a).s; })[0];
  var state = { q: '', fd: '', fr: '', lookup: Z.takeLookup() || topRisk.id, tamper: null, verify: null };

  function renderReceipt(msg) {
    var d = Z.find(state.lookup), field = $('#lookup-field');
    $('#lookup-id').value = state.lookup || '';
    field.classList.toggle('invalid', !d);
    if (d) {
      $('#receipt').innerHTML = '<div class="ticket-wrap" style="margin:0 22px 22px">' + U.ticket(d) + '</div>';
    } else {
      $('#lookup-err').textContent = state.lookup ? 'No deposit has that ID. Check the ID on the farmer’s ticket and try again.' : 'Enter a tracking ID.';
      $('#receipt').innerHTML = '';
    }
  }

  function filtered() {
    var q = state.q.trim().toLowerCase();
    return Z.DEPOSITS.slice().reverse().filter(function (d) {
      if (state.fd && d.depot !== state.fd) return false;
      if (state.fr && Z.riskOf(d).lv !== state.fr) return false;
      return !q || (d.id + ' ' + d.farmer + ' ' + Z.depotName(d.depot)).toLowerCase().indexOf(q) > -1;
    });
  }
  function renderLedger() {
    var list = filtered();
    $('#ledger-count').textContent = list.length + ' of ' + Z.DEPOSITS.length + ' deposits';
    $('#ledger').innerHTML = list.length ?
      '<table><thead><tr><th>Tracking ID</th><th>Farmer</th><th>Depot</th><th class="r">Bags</th><th class="r">Moisture</th><th>Risk</th><th>Payout</th><th>Received</th></tr></thead><tbody>' +
      list.map(function (d) {
        var r = Z.riskOf(d);
        return '<tr><td><button class="idlink" data-id="' + d.id + '" type="button">' + d.id + '</button></td><td>' + esc(d.farmer) + '</td><td>' + Z.depotById(d.depot).name +
          '</td><td class="r mono">' + nf(d.bags) + '</td><td class="r mono">' + d.m.toFixed(1) + '%</td><td>' + U.riskPill(r) +
          '</td><td><span class="pill ' + (Z.PAY[d.pay] || 's-warn') + '">' + d.pay + '</span></td><td class="mono">' + Z.fmtDate(d.ts) + '</td></tr>';
      }).join('') + '</tbody></table>' :
      '<p class="empty">No deposits match. Clear the search or the filters.</p>';
  }
  function renderVerify() {
    var v = state.verify, el = $('#verify-msg');
    $('#tamper-btn').textContent = state.tamper ? 'Undo the edit' : 'Simulate an edit';
    if (!v) { el.innerHTML = ''; return; }
    el.innerHTML = v.ok ?
      '<span class="v-ok"><strong>Chain intact.</strong> ' + v.n + ' records checked, each linked to the one before it.</span>' :
      '<span class="v-bad"><strong>Chain broken.</strong> <span class="mono">' + v.at.id + '</span> no longer matches its signature. Its details changed after it was saved.</span>';
  }

  $('#fd').innerHTML = '<option value="">All depots</option>' + D.map(function (d) { return '<option value="' + d.id + '">' + d.name + '</option>'; }).join('');

  $('#lookup-form').addEventListener('submit', function (e) {
    e.preventDefault();
    state.lookup = $('#lookup-id').value.trim().toUpperCase();
    renderReceipt();
  });
  $('#lookup-id').addEventListener('input', function () { $('#lookup-field').classList.remove('invalid'); });
  $('#q').addEventListener('input', function (e) { state.q = e.target.value; renderLedger(); });
  $('#fd').addEventListener('change', function (e) { state.fd = e.target.value; renderLedger(); });
  $('#fr').addEventListener('change', function (e) { state.fr = e.target.value; renderLedger(); });

  document.addEventListener('click', function (e) {
    var t = e.target.closest('button');
    if (!t) return;
    if (t.dataset.id) {
      state.lookup = t.dataset.id; renderReceipt();
      var calm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
      $('#lookup-panel').scrollIntoView({ behavior: calm ? 'auto' : 'smooth', block: 'start' });
      return;
    }
    var a = t.dataset.act;
    if (a === 'verify') { state.verify = Z.verifyLedger(); renderVerify(); }
    if (a === 'tamper') {
      if (state.tamper) { state.tamper.d.bags = state.tamper.bags; state.tamper = null; }
      else { var d = Z.DEPOSITS[4]; state.tamper = { d: d, bags: d.bags }; d.bags += 20; }
      state.verify = Z.verifyLedger();
      renderVerify(); renderReceipt(); renderLedger();
    }
    if (a === 'reset') { Z.resetExtras(); U.toast('Sample data restored'); setTimeout(function () { location.reload(); }, 500); }
  });

  renderReceipt(); renderLedger(); renderVerify();
})();
