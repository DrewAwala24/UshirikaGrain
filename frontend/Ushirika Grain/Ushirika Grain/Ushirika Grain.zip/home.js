/* Home page: farmer receipt lookup (public, no log in needed). */
(function () {
  'use strict';
  var Z = window.Ushirika, U = window.UshirikaUI;
  var form = document.getElementById('lookup-form');
  if (!form || !U) return;
  var input = document.getElementById('lookup-id');
  var out = document.getElementById('lookup-result');
  var err = document.getElementById('lookup-err');
  var field = input.closest('.field');

  function empty() {
    out.innerHTML = '<div class="lookup-empty">' + U.icon('search') + '<p><strong>Your receipt will show here.</strong><br>Enter the tracking ID printed on your ticket or sent by SMS.</p></div>';
  }
  function show(d) {
    out.innerHTML = '<div class="ticket-wrap">' + U.ticket(d) + '</div>';
  }
  function run(id) {
    var d = Z.find(id);
    if (!id.trim()) {
      field.classList.add('invalid'); err.textContent = 'Enter the tracking ID from your ticket.'; empty(); return;
    }
    if (!d) {
      field.classList.add('invalid'); err.textContent = 'No deposit has that ID. Check the ID on your ticket and try again.'; empty(); return;
    }
    field.classList.remove('invalid');
    show(d);
  }
  form.addEventListener('submit', function (e) { e.preventDefault(); run(input.value); });
  input.addEventListener('input', function () { field.classList.remove('invalid'); });
  document.getElementById('lookup-sample').addEventListener('click', function () {
    var d = Z.DEPOSITS[1];
    input.value = d.id;
    run(d.id);
  });
  empty();
})();
