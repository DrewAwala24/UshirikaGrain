/* New intake: validated form, live AI check, depot picker, receipt on save. */
(function () {
  'use strict';
  if (window.UshirikaBlocked) return;
  var Z = window.Ushirika, U = window.UshirikaUI, D = Z.DEPOTS, nf = Z.nf;
  var $ = function (s) { return document.querySelector(s); };
  var form = $('#intake-form');
  var state = { depot: 'KTL', lastId: null };

  var subs = D.map(function (d) { return d.name.replace(' Central', ''); }).concat(['Other Trans Nzoia ward']);
  $('#f-sub').innerHTML = '<option value="">Choose sub-county</option>' + subs.map(function (s) { return '<option>' + s + '</option>'; }).join('');

  var val = {
    name: function () { return $('#f-name').value.trim(); },
    phone: function () { return $('#f-phone').value.replace(/[\s-]/g, ''); },
    sub: function () { return $('#f-sub').value; },
    crop: function () { return form.querySelector('input[name="produce"]:checked').value; },
    bags: function () { return parseInt($('#f-bags').value, 10); },
    moist: function () { return parseFloat($('#f-moist').value); }
  };

  /* ---------- validation ---------- */
  var rules = {
    name: function () { var v = val.name(); return v.length < 3 || !/[a-zA-Z]/.test(v) ? 'Enter the farmer’s full name.' : ''; },
    phone: function () { return /^(07|01)\d{8}$/.test(val.phone()) ? '' : 'Enter a 10-digit number starting with 07 or 01.'; },
    sub: function () { return val.sub() ? '' : 'Choose the farmer’s sub-county.'; },
    bags: function () { var v = val.bags(); return v >= 1 && v <= 2000 ? '' : 'Enter a whole number of bags, from 1 to 2,000.'; },
    moist: function () { var v = val.moist(); return v >= 5 && v <= 30 ? '' : 'Enter a moisture reading between 5% and 30%.'; }
  };
  function check(key) {
    var f = form.querySelector('[data-field="' + key + '"]'), msg = rules[key]();
    f.classList.toggle('invalid', !!msg);
    f.querySelector('.field-err').textContent = msg;
    f.querySelector('.control').setAttribute('aria-invalid', msg ? 'true' : 'false');
    return !msg;
  }
  Object.keys(rules).forEach(function (k) {
    var el = form.querySelector('[data-field="' + k + '"] .control');
    el.addEventListener('blur', function () { check(k); });
    el.addEventListener('input', function () { if (el.closest('.invalid')) check(k); });
  });

  /* ---------- depot picker ---------- */
  function renderDepots() {
    var bags = val.bags() || 0;
    $('#depot-opts').innerHTML = D.map(function (d) {
      var m = Z.metrics(d), s = Z.ST[m.st], free = d.cap - d.stored, tooSmall = bags > free;
      return '<div><input type="radio" name="depot" id="d-' + d.id + '" value="' + d.id + '"' + (state.depot === d.id ? ' checked' : '') + '>' +
        '<label for="d-' + d.id + '" class="' + s.cls + (tooSmall ? ' is-full' : '') + '">' +
        '<span class="opt-top"><span>' + d.name + '</span><span class="pill ' + s.cls + '">' + s.t + '</span></span>' +
        '<span class="mini-bar"><i style="width:' + Math.min(100, Math.round(m.util * 100)) + '%"></i></span>' +
        '<span class="opt-meta mono">' + nf(free) + ' bags free' + (tooSmall ? ' · too small' : '') + '</span></label></div>';
    }).join('');
  }
  $('#depot-opts').addEventListener('change', function (e) {
    if (e.target.name === 'depot') { state.depot = e.target.value; renderCheck(); }
  });

  /* ---------- live AI check ---------- */
  function scaleHTML(m) {
    var p = Math.max(0, Math.min(1, (m - 11) / 9)) * 100;
    return '<div class="scale" aria-hidden="true"><i style="left:' + p.toFixed(1) + '%"></i></div><div class="scale-l"><span>11%</span><span>13.5% safe limit</span><span>20%</span></div>';
  }
  function renderCheck() {
    var m = val.moist(), bags = val.bags(), dep = Z.depotById(state.depot), h = '';
    if (m > 0) {
      var sc = Z.score(m, 14), L = Z.LV[Z.level(sc)];
      h += '<div class="check-sec"><div class="label">Spoilage risk after 14 days in store</div>' +
        '<div class="check-top"><span class="big mono">' + sc + '</span><span class="pill ' + L.cls + '">' + L.t + ' risk</span></div>' +
        '<p style="margin-top:12px">' + (m > Z.LIMIT ? 'At <strong class="mono">' + m.toFixed(1) + '%</strong> moisture this lot is above the safe limit. ' : 'At <strong class="mono">' + m.toFixed(1) + '%</strong> moisture this lot is within the safe limit. ') +
        '<strong>' + L.act + '.</strong></p>' + scaleHTML(m) + '</div>';
    } else {
      h += '<div class="check-sec"><p class="muted">Enter the moisture reading to see the spoilage forecast.</p></div>';
    }
    var free = dep.cap - dep.stored;
    h += '<div class="check-sec"><div class="label">Depot space</div><p style="margin-top:8px"><strong>' + dep.name + '</strong> has <span class="mono">' + nf(free) + '</span> bags free.</p>';
    if (bags > 0) {
      if (bags > free) {
        var alt = D.filter(function (x) { return x.id !== dep.id; }).sort(function (a, b) { return (b.cap - b.stored) - (a.cap - a.stored); })[0];
        h += '<p style="margin-top:10px"><span class="pill s-crit">Over capacity by ' + nf(bags - free) + ' bags</span></p>' +
          '<p style="margin-top:10px">Try <strong>' + alt.name + '</strong>, which has ' + nf(alt.cap - alt.stored) + ' bags free.</p>';
      } else {
        var after = (dep.stored + bags) / dep.cap;
        h += '<p style="margin-top:10px"><span class="pill ' + (after >= .9 ? 's-warn' : 's-ok') + '">' + Math.round(after * 100) + '% full after this delivery</span></p>';
      }
    }
    $('#check').innerHTML = h + '</div>';
  }
  function updateKg() {
    var b = val.bags();
    $('#bags-kg').textContent = b > 0 ? '= ' + nf(b * Z.KG) + ' kg' : 'Each bag is 90 kg';
  }
  ['f-bags', 'f-moist'].forEach(function (id) {
    $('#' + id).addEventListener('input', function () { updateKg(); renderDepots(); renderCheck(); });
  });

  /* ---------- submit ---------- */
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var box = $('#form-error');
    var ok = true;
    Object.keys(rules).forEach(function (k) { if (!check(k)) ok = false; });
    if (!ok) {
      box.textContent = 'Fix the highlighted fields and save again.'; box.classList.add('show');
      var first = form.querySelector('.invalid .control'); if (first) first.focus();
      return;
    }
    var dep = Z.depotById(state.depot), bags = val.bags();
    if (bags > dep.cap - dep.stored) {
      box.textContent = dep.name + ' depot has only ' + nf(dep.cap - dep.stored) + ' bags of space. Choose another depot.';
      box.classList.add('show');
      $('#depot-opts').scrollIntoView({ block: 'center' });
      return;
    }
    box.classList.remove('show');
    var d = Z.recordIntake({ farmer: val.name(), phone: val.phone().slice(-3), sub: val.sub(), depot: state.depot, crop: val.crop(), bags: bags, m: val.moist() });
    state.lastId = d.id;
    $('#success-ticket').innerHTML = '<div class="ticket-wrap">' + U.ticket(d) + '</div>';
    $('#intake-form-wrap').hidden = true;
    $('#intake-success').hidden = false;
    window.scrollTo(0, 0);
    U.toast('Deposit recorded');
  });

  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-act]');
    if (!t) return;
    if (t.dataset.act === 'another') {
      form.querySelectorAll('[data-field="name"] .control, [data-field="phone"] .control').forEach(function (c) { c.value = ''; });
      Object.keys(rules).forEach(function (k) { form.querySelector('[data-field="' + k + '"]').classList.remove('invalid'); });
      $('#intake-success').hidden = true;
      $('#intake-form-wrap').hidden = false;
      renderDepots(); renderCheck();
      $('#f-name').focus();
    }
    if (t.dataset.act === 'view' && state.lastId) { Z.setLookup(state.lastId); location.href = 'deposits.html'; }
    if (t.dataset.act === 'clear') {
      form.reset();
      Object.keys(rules).forEach(function (k) { form.querySelector('[data-field="' + k + '"]').classList.remove('invalid'); });
      $('#form-error').classList.remove('show');
      state.depot = 'KTL'; updateKg(); renderDepots(); renderCheck();
    }
  });

  updateKg(); renderDepots(); renderCheck();
})();
