/* Log in: validated form. Front-end only until the Spring Boot login exists. */
(function () {
  'use strict';
  var Z = window.Ushirika, U = window.UshirikaUI;
  if (!U) return;
  var $ = function (s) { return document.querySelector(s); };
  var form = $('#login-form');
  var email = $('#l-email'), pass = $('#l-pass');

  if (Z.session.get()) { location.replace(Z.session.takeNext() || 'dashboard.html'); return; }

  function setErr(input, msg) {
    var f = input.closest('.field');
    f.classList.toggle('invalid', !!msg);
    f.querySelector('.field-err').textContent = msg;
    input.setAttribute('aria-invalid', msg ? 'true' : 'false');
    return !msg;
  }
  var checks = {
    email: function () { return setErr(email, /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim()) ? '' : 'Enter a valid email address.'); },
    pass: function () { return setErr(pass, pass.value.length >= 6 ? '' : 'Your password must be at least 6 characters.'); }
  };
  email.addEventListener('blur', checks.email);
  pass.addEventListener('blur', checks.pass);
  email.addEventListener('input', function () { if (email.closest('.invalid')) checks.email(); });
  pass.addEventListener('input', function () { if (pass.closest('.invalid')) checks.pass(); });

  $('#reveal').addEventListener('click', function (e) {
    var show = pass.type === 'password';
    pass.type = show ? 'text' : 'password';
    e.currentTarget.textContent = show ? 'Hide' : 'Show';
    e.currentTarget.setAttribute('aria-pressed', String(show));
  });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var a = checks.email(), b = checks.pass();
    if (!(a && b)) { (a ? pass : email).focus(); return; }
    var btn = $('#login-btn');
    btn.disabled = true; btn.textContent = 'Signing in…';
    Z.session.set({ email: email.value.trim(), name: Z.session.nameFromEmail(email.value.trim()), role: $('#l-role').value }, $('#l-remember').checked);
    setTimeout(function () { location.href = Z.session.takeNext() || 'dashboard.html'; }, 500);
  });
})();
